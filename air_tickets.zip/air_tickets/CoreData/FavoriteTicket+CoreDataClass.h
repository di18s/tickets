//
//  FavoriteTicket+CoreDataClass.h
//  air_tickets
//
//  Created by Дмитрий on 05/04/2019.
//  Copyright © 2019 Dmitry. All rights reserved.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface FavoriteTicket : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "FavoriteTicket+CoreDataProperties.h"
